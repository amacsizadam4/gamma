def powerrr(a,b):
    result = a**b
    return result

print(powerrr(3,-1))


import pow

import unittest

class TestPower(unittest.TestCase):
    def test1(self):
        self.assertEqual(pow.powerrr(2,3),8)



if __name__=='__main__':
    unittest.main()

"Modern Programming Languages Lecture Projects" 
